package com.ohgiraffers.dto;

public class MemberDTO {
}
